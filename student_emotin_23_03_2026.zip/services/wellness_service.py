import random

tips = {
    "sadness": ["Go for a short walk", "Listen to relaxing music"],
    "anger": ["Try deep breathing", "Drink water and relax"],
    "fear": ["Practice mindfulness", "Talk to someone you trust"],
    "joy": ["Share happiness with friends", "Write gratitude journal"],
    "neutral": ["Maintain regular sleep schedule"]
}

def get_wellness_tip(emotion):
    return random.choice(tips.get(emotion, tips["neutral"]))

def calculate_mental_score(user_id):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("""
        SELECT detected_emotion FROM mood_history
        WHERE user_id=%s ORDER BY date DESC LIMIT 10
    """,(user_id,))
    moods = cursor.fetchall()
    conn.close()

    score = 100
    for mood in moods:
        if mood["detected_emotion"] in ["sadness","fear","anger"]:
            score -= 10

    return max(score, 0)