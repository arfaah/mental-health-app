from transformers import pipeline

model = pipeline(
    "text-classification",
    model="j-hartmann/emotion-english-distilroberta-base"
)

def detect_emotion(text):
    # result = model(text)[0]
    # return result["label"].lower()
    text_lower = text.lower()

    # --------------------
    # Custom Mental Health Detection
    # --------------------

    guilt_keywords = ["guilty", "regret", "my fault", "i messed up"]
    shame_keywords = ["ashamed", "embarrassed", "i am worthless"]
    lonely_keywords = ["lonely", "alone", "no one cares", "isolated"]
    stress_keywords = ["stressed", "pressure", "overwhelmed", "burnout"]

    if any(word in text_lower for word in guilt_keywords):
        return "guilt"

    if any(word in text_lower for word in shame_keywords):
        return "shame"

    if any(word in text_lower for word in lonely_keywords):
        return "loneliness"

    if any(word in text_lower for word in stress_keywords):
        return "stress"

    # --------------------
    # Default Transformer Detection
    # --------------------
    result = model(text)[0]
    return result["label"].lower()