
from services.emotion_service import detect_emotion
from services.wellness_service import get_wellness_tip

def generate_reply(message):
    emotion = detect_emotion(message)

    responses = {

    "sadness": "I understand you may be feeling sad. You are not alone.",
    
    "anger": "Take a deep breath. Let us calm your mind together.",
    
    "joy": "That is wonderful to hear! Keep smiling.",
    
    "fear": "It is okay to feel afraid sometimes. Try slow breathing exercises.",
    
    "neutral": "I am here to listen. Tell me more.",
    
    "surprise": "That sounds unexpected. How are you feeling about it now?",
    
    "disgust": "It seems something really disturbed you. Would you like to share more?",

    "guilt": "It’s okay to make mistakes. What matters is learning and moving forward with kindness toward yourself.",

    "shame": "You are not defined by one moment. Would you like to talk about what made you feel this way?",

    "loneliness": "Feeling alone can be very heavy. I'm here with you right now. Would you like to talk more?",

    "stress": "It sounds like you are under pressure. Let’s take a short pause and try a calming breathing exercise."
    }

    tip = get_wellness_tip(emotion)

    return {
        "emotion": emotion,
        "reply": responses.get(emotion, "I am here to support you."),
        "tip": tip
    }

def crisis_check(message):
    crisis_keywords = [
        "want to die",
        "kill myself",
        "suicide",
        "end my life",
        "no reason to live"
    ]

    for word in crisis_keywords:
        if word in message.lower():
            return True
    return False