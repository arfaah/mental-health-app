from utils.db import get_connection

def save_mood(user_id, emotion, tip=None, activity=None, score=100):

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO mood_history
        (user_id, detected_emotion, tip, activity, wellness_score)
        VALUES (%s, %s, %s, %s, %s)
    """, (user_id, emotion, tip, activity, score))

    conn.commit()
    conn.close()                                             