from utils.db import get_connection

def save_mood(user_id, emotion):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO mood_history (user_id, detected_emotion) VALUES (%s,%s)",
        (user_id, emotion)
    )
    conn.commit()
    conn.close()

def get_mood_history(user_id):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute(
        "SELECT detected_emotion, recorded_at FROM mood_history WHERE user_id=%s ORDER BY recorded_at DESC",
        (user_id,)
    )
    data = cursor.fetchall()
    conn.close()
    return data