from utils.db import get_connection

def create_student(user_id, full_name):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO students (user_id, full_name) VALUES (%s,%s)",
        (user_id, full_name)
    )
    conn.commit()
    conn.close()

def get_student_by_user(user_id):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute(
        "SELECT * FROM students WHERE user_id=%s",
        (user_id,)
    )
    student = cursor.fetchone()
    conn.close()
    return student