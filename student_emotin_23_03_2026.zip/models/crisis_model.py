from utils.db import get_connection

def save_crisis(user_id, message):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO crisis_alerts (user_id, message) VALUES (%s,%s)",
        (user_id, message)
    )
    conn.commit()
    conn.close()