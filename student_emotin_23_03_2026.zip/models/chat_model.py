from utils.db import get_connection

def save_chat(user_id, message, reply, emotion):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO chat_history 
        (user_id, student_message, bot_reply, detected_emotion)
        VALUES (%s,%s,%s,%s)
    """, (user_id, message, reply, emotion))
    conn.commit()
    conn.close()