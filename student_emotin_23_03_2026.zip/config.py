class Config:
    SECRET_KEY = "super_secret_key"

    DB_HOST = "localhost"
    DB_USER = "root"
    DB_PASSWORD = ""
    DB_NAME = "mental_health"