from flask import Flask
from config import Config
from extensions import login_manager, bcrypt
from routes.auth_routes import auth_bp
from routes.chat_routes import chat_bp
from routes.student_routes import student_bp
from models.user_model import User
from utils.db import get_connection
from routes.admin_routes import admin_bp

app = Flask(__name__)
app.config.from_object(Config)

login_manager.init_app(app)
bcrypt.init_app(app)

@login_manager.user_loader
def load_user(user_id):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM users WHERE id=%s",(user_id,))
    user = cursor.fetchone()
    conn.close()

    if user:
        return User(user["id"], user["email"], user["role"])
    return None

app.register_blueprint(auth_bp)
app.register_blueprint(chat_bp)
app.register_blueprint(student_bp)
app.register_blueprint(admin_bp)


if __name__ == "__main__":
    app.run(debug=True)