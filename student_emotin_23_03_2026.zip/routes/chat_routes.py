from flask import Blueprint, request, jsonify, render_template
from flask_login import login_required, current_user
from utils.db import get_connection
from datetime import datetime

from services.chatbot import generate_reply, crisis_check
from services.mood_service import save_mood

chat_bp = Blueprint("chat", __name__)

def get_activity(emotion):
    activity_map = {
        "stress": "Try deep breathing or meditation 🧘",
        "sadness": "Listen to calming music 🎧",
        "anger": "Take a short walk 🚶",
        "fear": "Write your thoughts ✍",
        "joy": "Share your happiness 😊"
    }
    return activity_map.get(emotion, "Take a short break")

@chat_bp.route("/chat", methods=["POST"])
@login_required
def chat():

    data = request.get_json()
    msg = data.get("message", "").strip()

    if not msg:
        return jsonify({"error": "Empty message"}), 400

    user_id = current_user.id

    # 🚨 Crisis Handling
    if crisis_check(msg):

        reply = "I’m really sorry you're feeling this way. Please seek immediate help."
        tip = "Contact local emergency support immediately."

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO chat_history 
            (user_id, user_message, bot_reply, detected_emotion, tip)
            VALUES (%s,%s,%s,%s,%s)
        """, (user_id, msg, reply, "crisis", tip))

        conn.commit()
        conn.close()

        return jsonify({
            "emotion": "crisis",
            "reply": reply,
            "tip": tip,
            "timestamp": datetime.now().strftime("%H:%M"),
            "alert": True   # 🔥 always alert in crisis
        })

    # 🤖 Normal AI
    result = generate_reply(msg)

    emotion = result.get("emotion", "neutral")
    reply = result.get("reply", "")
    tip = result.get("tip", "")

    activity = get_activity(emotion)

    # Save mood
    save_mood(user_id, emotion, tip, activity, 100)

    # Save chat
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO chat_history 
        (user_id, user_message, bot_reply, detected_emotion, tip)
        VALUES (%s,%s,%s,%s,%s)
    """, (user_id, msg, reply, emotion, tip))

    conn.commit()
    conn.close()

    # 🔥 Guidance Alert Logic
    high_stress = ["stress","sadness","fear","guilt","loneliness","anger"]

    return jsonify({
        "emotion": emotion,
        "reply": reply,
        "tip": tip,
        "timestamp": datetime.now().strftime("%H:%M"),
        "alert": emotion in high_stress   # ✅ NEW
    })


@chat_bp.route("/chat", methods=["GET"])
@login_required
def chat_page():

    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("""
        SELECT user_message, bot_reply, detected_emotion, tip, created_at
        FROM chat_history
        WHERE user_id=%s
        ORDER BY created_at ASC
    """, (current_user.id,))

    chats = cursor.fetchall()
    conn.close()

    return render_template("chat.html", chats=chats)