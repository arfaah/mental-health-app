@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        full_name = request.form["full_name"]
        email = request.form["email"]
        password = bcrypt.generate_password_hash(
            request.form["password"]
        ).decode("utf-8")

        conn = get_connection()
        cursor = conn.cursor()

        # Insert into users
        cursor.execute("""
            INSERT INTO users (email, password_hash, role)
            VALUES (%s,%s,'student')
        """, (email, password))

        user_id = cursor.lastrowid

        # Insert into students
        cursor.execute("""
            INSERT INTO students (user_id, full_name)
            VALUES (%s,%s)
        """, (user_id, full_name))

        conn.commit()
        conn.close()

        return redirect(url_for("auth.login"))

    return render_template("register.html")