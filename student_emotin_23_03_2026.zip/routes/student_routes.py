from flask import Blueprint, render_template
from flask_login import login_required, current_user
from utils.db import get_connection
import random

student_bp = Blueprint("student", __name__)

def get_affirmation():
    return random.choice([
        "You are stronger than you think.",
        "Every day is a fresh start.",
        "You are doing your best, and that is enough.",
        "Your mental health matters.",
        "Take one step at a time."
    ])

@student_bp.route("/student")
@login_required
def dashboard():

    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    # Mood history
    cursor.execute("""
        SELECT detected_emotion, recorded_at, tip, activity
        FROM mood_history
        WHERE user_id=%s
        ORDER BY recorded_at DESC
    """, (current_user.id,))
    moods = cursor.fetchall()

    # Weekly trend (SAFE VERSION)
    cursor.execute("""
        SELECT DATE(recorded_at) as date, COUNT(*) as count
        FROM mood_history
        WHERE user_id=%s
        GROUP BY DATE(recorded_at)
        ORDER BY DATE(recorded_at)
    """, (current_user.id,))
    weekly = cursor.fetchall()

    # Emotion distribution
    cursor.execute("""
        SELECT detected_emotion, COUNT(*) as count
        FROM mood_history
        WHERE user_id=%s
        GROUP BY detected_emotion
    """, (current_user.id,))
    distribution = cursor.fetchall()

    conn.close()

    # ✅ SAFE CHART DATA (NO EMPTY ISSUE)
    if not weekly:
        week_labels = ["No Data"]
        week_values = [0]
    else:
        week_labels = [str(w["date"]) for w in weekly]
        week_values = [w["count"] for w in weekly]

    if not distribution:
        dist_labels = ["No Data"]
        dist_values = [1]
    else:
        dist_labels = [d["detected_emotion"] for d in distribution]
        dist_values = [d["count"] for d in distribution]

    # Wellness Score
    negative = ["sadness","stress","fear","guilt","loneliness","anger"]
    negative_count = sum(d["count"] for d in distribution if d["detected_emotion"] in negative)
    total_count = sum(d["count"] for d in distribution)

    wellness_score = 100
    if total_count > 0:
        wellness_score = max(0, 100 - int((negative_count / total_count) * 100))

    # Stress alert
    stress_alert = total_count > 0 and (negative_count / total_count) > 0.5

    # Activity (from latest record)
    activity = moods[0]["activity"] if moods and moods[0]["activity"] else "Take care and relax"

    return render_template(
        "student_dashboard.html",
        moods=moods,
        week_labels=week_labels,
        week_values=week_values,
        dist_labels=dist_labels,
        dist_values=dist_values,
        wellness_score=wellness_score,
        affirmation=get_affirmation(),
        stress_alert=stress_alert,
        activity=activity
    )