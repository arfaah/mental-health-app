from flask import Blueprint, render_template
from flask_login import login_required, current_user
from utils.db import get_connection

admin_bp = Blueprint("admin", __name__)

def admin_required(func):
    from functools import wraps
    from flask import abort

    @wraps(func)
    def wrapper(*args, **kwargs):
        if current_user.role != "admin":
            abort(403)
        return func(*args, **kwargs)
    return wrapper

@admin_bp.route("/admin")
@login_required
@admin_required
def dashboard():

    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT COUNT(*) AS total FROM students")
    total_students = cursor.fetchone()["total"]

    cursor.execute("""
        SELECT detected_emotion, COUNT(*) AS count
        FROM mood_history
        GROUP BY detected_emotion
    """)
    # Safe fallback
    emotions = cursor.fetchall() or []

    # Calculate total moods (BEST PRACTICE)
    total_moods = sum(e["count"] for e in emotions) if emotions else 0
    cursor.execute("""
        SELECT COUNT(*) AS total FROM crisis_alerts
        WHERE alert_status='pending'
    """)
    crisis_count = cursor.fetchone()["total"]

    conn.close()

    # Prepare chart data
    labels = [e["detected_emotion"] for e in emotions]
    values = [e["count"] for e in emotions]

    return render_template(
    "admin_dashboard.html",
    total_students=total_students,
    emotions=emotions,
    crisis_count=crisis_count,
    labels=labels,
    values=values,
    total_moods=total_moods   
    )