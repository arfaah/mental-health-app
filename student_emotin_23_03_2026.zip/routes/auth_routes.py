from flask import Blueprint, render_template, request, redirect, url_for
from extensions import bcrypt
from utils.db import get_connection
from flask_login import login_user
from models.user_model import User
from flask_login import logout_user

auth_bp = Blueprint("auth", __name__)

@auth_bp.route("/", methods=["GET","POST"])
@auth_bp.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        conn = get_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users WHERE email=%s",(email,))
        user = cursor.fetchone()
        conn.close()

        if user and bcrypt.check_password_hash(user["password_hash"], password):
            login_user(User(user["id"], user["email"], user["role"]))
            if user["role"] == 'admin':
                return redirect(url_for("admin.dashboard"))
            else:
                return redirect(url_for("student.dashboard"))


    return render_template("login.html")

@auth_bp.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        full_name = request.form["full_name"]
        email = request.form["email"]
        password = bcrypt.generate_password_hash(
            request.form["password"]
        ).decode("utf-8")

        conn = get_connection()
        cursor = conn.cursor()

        # Insert into users table
        cursor.execute(
            "INSERT INTO users (email, password_hash, role) VALUES (%s,%s,'student')",
            (email, password)
        )

        user_id = cursor.lastrowid

        # Insert into students table
        cursor.execute(
            "INSERT INTO students (user_id, full_name) VALUES (%s,%s)",
            (user_id, full_name)
        )

        conn.commit()
        conn.close()

        return redirect(url_for("auth.login"))

    return render_template("register.html")

@auth_bp.route("/logout")
def logout():
    logout_user()
    return redirect(url_for("auth.login"))